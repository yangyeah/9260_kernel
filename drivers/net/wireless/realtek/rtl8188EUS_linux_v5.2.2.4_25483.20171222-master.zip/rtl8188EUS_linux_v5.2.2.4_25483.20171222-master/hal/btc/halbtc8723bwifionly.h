#ifndef __INC_HAL8723BWIFIONLYHWCFG_H
#define __INC_HAL8723BWIFIONLYHWCFG_H

VOID
ex_hal8723b_wifi_only_hw_config(
	IN struct wifi_only_cfg *pwifionlycfg
	);
#endif
