# rtl8188EUS_linux_v5.2.2.4_25483.20171222
Driver for Wireless N Nano USB Adapter TL-WN725N
